package com.example.titanforge.entities;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.AttributeModifierMap;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.NearestAttackableTargetGoal;
import net.minecraft.entity.ai.goal.WaterAvoidingRandomWalkingGoal;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.world.World;

import java.util.UUID;

public class BlindGolemEntity extends MonsterEntity {
    private UUID ownerId;
    private int lifespan = 30 * 20;

    public BlindGolemEntity(EntityType<? extends MonsterEntity> type, World world) {
        super(type, world);
    }

    public static AttributeModifierMap.MutableAttribute registerAttributes() {
        return MonsterEntity.func_233666_p_()
                .createMutableAttribute(Attributes.MAX_HEALTH, 40.0D)
                .createMutableAttribute(Attributes.MOVEMENT_SPEED, 0.25D)
                .createMutableAttribute(Attributes.ATTACK_DAMAGE, 7.0D)
                .createMutableAttribute(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomWalkingGoal(this, 1.0D));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, LivingEntity.class,
                10, true, false,
                e -> !(e instanceof BlindGolemEntity) && !e.getUniqueID().equals(ownerId)));
    }

    public void setOwner(UUID id) {
        this.ownerId = id;
    }

    public UUID getOwnerId() {
        return ownerId;
    }

    @Override
    public void livingTick() {
        super.livingTick();
        if (--lifespan <= 0 && !world.isRemote) {
            com.example.titanforge.NecroChokeTracker.onGolemRemoved(ownerId);
            ((net.minecraft.world.server.ServerWorld) world).spawnParticle(
                    net.minecraft.particles.ParticleTypes.ASH,
                    getPosX(), getPosY() + 1, getPosZ(), 30, 0.3, 0.5, 0.3, 0.01);
            this.remove();
        }
    }
}
