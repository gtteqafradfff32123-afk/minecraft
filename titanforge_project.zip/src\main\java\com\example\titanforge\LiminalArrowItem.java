package com.example.titanforge;

import com.example.titanforge.entities.LiminalArrowEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.entity.projectile.AbstractArrowEntity;

public class LiminalArrowItem extends ArrowItem {
    public LiminalArrowItem(Properties props) { super(props); }

    @Override
    public AbstractArrowEntity createArrow(World world, ItemStack stack, LivingEntity shooter) {
        return new LiminalArrowEntity(world, shooter);
    }
}
