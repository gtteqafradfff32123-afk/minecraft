package com.example.titanforge.entities;

import com.example.titanforge.LiminalManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.world.server.ServerWorld;

public class LiminalArrowEntity extends ArrowEntity {
    public LiminalArrowEntity(net.minecraft.entity.EntityType<?> type, net.minecraft.world.World world) {
        super((net.minecraft.entity.EntityType<? extends net.minecraft.entity.projectile.ArrowEntity>) type, world);
    }

    public LiminalArrowEntity(net.minecraft.world.World world, LivingEntity shooter) {
        super(com.example.titanforge.ModEntities.LIMINAL_ARROW.get(), world);
        this.setPosition(shooter.getPosX(), shooter.getPosY() + shooter.getEyeHeight() - 0.1, shooter.getPosZ());
        this.setShooter(shooter);
        if (shooter instanceof PlayerEntity) {
            this.pickupStatus = PickupStatus.ALLOWED;
        }
    }

    @Override
    protected void onEntityHit(EntityRayTraceResult ray) {
        super.onEntityHit(ray);
        if (world.isRemote) return;
        Entity hit = ray.getEntity();
        if (!(hit instanceof LivingEntity)) return;

        ServerPlayerEntity owner = (getShooter() instanceof ServerPlayerEntity)
            ? (ServerPlayerEntity) getShooter() : null;

        int dur = 120 + rand.nextInt(120);
        LiminalManager.enter((LivingEntity) hit, owner, dur);
        this.remove();
    }
}
