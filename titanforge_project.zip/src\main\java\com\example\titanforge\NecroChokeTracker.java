package com.example.titanforge;

import com.example.titanforge.entities.BlindGolemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.DamageSource;
import net.minecraft.world.server.ServerWorld;

import java.util.*;

public class NecroChokeTracker {
    private static final Map<UUID, ChokeInstance> choked = new HashMap<>();
    private static final Map<UUID, Integer> activeGolems = new HashMap<>();

    private static class ChokeInstance {
        final LivingEntity target;
        final ServerPlayerEntity owner;
        int duration;

        ChokeInstance(LivingEntity target, ServerPlayerEntity owner, int duration) {
            this.target = target;
            this.owner = owner;
            this.duration = duration;
        }
    }

    public static void mark(LivingEntity target, ServerPlayerEntity owner, int duration) {
        choked.put(target.getUniqueID(), new ChokeInstance(target, owner, duration));
    }

    public static void tick(ServerWorld world) {
        Iterator<Map.Entry<UUID, ChokeInstance>> it = choked.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, ChokeInstance> entry = it.next();
            ChokeInstance inst = entry.getValue();
            if (inst.target == null || !inst.target.isAlive() || --inst.duration <= 0) {
                it.remove();
                continue;
            }
            if (inst.target.ticksExisted % 20 == 0) {
                inst.target.attackEntityFrom(ModDamageSources.NECROTIC_UNDERTOW, 1.0F);
            }
        }
    }

    public static void onDeath(LivingEntity dead, ServerWorld world) {
        if (dead instanceof BlindGolemEntity) {
            onGolemRemoved(((BlindGolemEntity) dead).getOwnerId());
            return;
        }

        UUID id = dead.getUniqueID();
        ChokeInstance inst = choked.remove(id);
        if (inst == null) return;

        UUID ownerId = inst.owner.getUniqueID();
        if (activeGolems.getOrDefault(ownerId, 0) >= 1) return;

        BlindGolemEntity golem = ModEntities.BLIND_GOLEM.get().create(world);
        if (golem != null) {
            golem.setPosition(dead.getPosX(), dead.getPosY(), dead.getPosZ());
            golem.setOwner(ownerId);
            world.addEntity(golem);
            activeGolems.put(ownerId, activeGolems.getOrDefault(ownerId, 0) + 1);
        }
    }

    public static void onGolemRemoved(UUID ownerId) {
        if (ownerId == null) return;
        int count = activeGolems.getOrDefault(ownerId, 0) - 1;
        if (count <= 0) activeGolems.remove(ownerId);
        else activeGolems.put(ownerId, count);
    }

    public static void cleanupOwner(UUID ownerId) {
        choked.entrySet().removeIf(e -> e.getValue().owner.getUniqueID().equals(ownerId));
        activeGolems.remove(ownerId);
    }
}
