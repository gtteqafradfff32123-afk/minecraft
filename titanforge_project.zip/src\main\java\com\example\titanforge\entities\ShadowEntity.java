package com.example.titanforge.entities;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.ai.attributes.AttributeModifierMap;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

import com.mojang.authlib.GameProfile;
import java.util.Optional;
import java.util.UUID;

public class ShadowEntity extends MobEntity {
    private static final DataParameter<Optional<UUID>> OWNER =
            EntityDataManager.createKey(ShadowEntity.class, DataSerializers.OPTIONAL_UNIQUE_ID);
    private GameProfile cachedProfile;

    public ShadowEntity(EntityType<? extends MobEntity> type, World world) {
        super(type, world);
    }

    public static AttributeModifierMap.MutableAttribute registerAttributes() {
        return MobEntity.func_233666_p_()
                .createMutableAttribute(Attributes.MAX_HEALTH, 1.0D)
                .createMutableAttribute(Attributes.MOVEMENT_SPEED, 0.35D);
    }

    @Override
    protected void registerData() {
        super.registerData();
        this.dataManager.register(OWNER, Optional.empty());
    }

    public void setOwner(UUID id) {
        this.cachedProfile = null;
        this.dataManager.set(OWNER, Optional.of(id));
    }

    public Optional<UUID> getOwnerId() {
        return this.dataManager.get(OWNER);
    }

    public GameProfile getOwnerProfile() {
        Optional<UUID> opt = getOwnerId();
        if (!opt.isPresent()) return null;

        UUID ownerId = opt.get();
        PlayerEntity player = this.world.getPlayerByUuid(ownerId);
        if (player != null) {
            cachedProfile = player.getGameProfile();
            return cachedProfile;
        }

        if (cachedProfile == null || !ownerId.equals(cachedProfile.getId())) {
            cachedProfile = new GameProfile(ownerId, "");
        }
        return cachedProfile;
    }

    @Override
    public void livingTick() {
        super.livingTick();
        if (world.isRemote) return;
        Optional<UUID> optOwner = getOwnerId();
        if (!optOwner.isPresent()) { this.remove(); return; }
        PlayerEntity target = world.getPlayerByUuid(optOwner.get());
        if (target == null) return;

        this.getLookController().setLookPositionWithEntity(target, 30F, 30F);

        double dist = this.getDistance(target);
        boolean lookingAtShadow = isEntityLookingAt(target, this, 0.6D);

        if (!lookingAtShadow && dist > 3.0D) {
            this.getNavigator().tryMoveToEntityLiving(target, 0.35D);
        } else {
            this.getNavigator().clearPath();
        }
        if (dist < 1.5D) {
            target.addPotionEffect(new EffectInstance(Effects.WITHER, 100, 1));
            this.remove();
        }
    }

    private boolean isEntityLookingAt(PlayerEntity player, MobEntity entity, double threshold) {
        Vector3d look = player.getLook(1.0F).normalize();
        Vector3d toEntity = entity.getPositionVec()
                .subtract(player.getPositionVec()).normalize();
        return look.dotProduct(toEntity) > threshold;
    }
}
