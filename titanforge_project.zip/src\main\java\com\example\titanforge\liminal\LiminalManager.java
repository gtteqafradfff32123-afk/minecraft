package com.example.titanforge.liminal;

import com.google.common.collect.ImmutableMap;
import com.example.titanforge.TitanForge;
import com.example.titanforge.entities.ShadowEntity;
import com.example.titanforge.entities.StunZombieEntity;
import com.example.titanforge.liminal.copy.ChunkCopyManager;
import com.example.titanforge.liminal.copy.CopyJob;
import com.example.titanforge.liminal.copy.DeltaCopier;
import com.example.titanforge.liminal.screen.LimboHandler;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.server.TicketType;
import java.util.*;

public class LiminalManager {
    private static final int RADIUS = 100;

    private static final Map<Block, Block> ROT_CHAIN = ImmutableMap.of(
        Blocks.GRASS_BLOCK, Blocks.DIRT,
        Blocks.DIRT,        Blocks.COARSE_DIRT,
        Blocks.COARSE_DIRT, Blocks.SOUL_SAND
    );

    public static class State {
        public UUID victim;
        public BlockPos center;
        public int ticks = 0;
        public int durationTicks;
        public int zombiesKilled = 0;
        public int zombiesAlive = 0;
        public boolean cloneReady = false;
        public boolean markDeadOnRejoin = false;
        public boolean shadowSpawned = false;
        public boolean frozen = false;
        public BlockPos realReturnPos;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    public static void applyLiminalHit(LivingEntity target) {
        target.addPotionEffect(new EffectInstance(Effects.BLINDNESS, Integer.MAX_VALUE, 0, false, false));
        target.addPotionEffect(new EffectInstance(Effects.SLOWNESS, Integer.MAX_VALUE, 255, false, false));
        target.addPotionEffect(new EffectInstance(Effects.JUMP_BOOST, Integer.MAX_VALUE, 128, false, false));
    }

    public static void enter(LivingEntity victim, ServerPlayerEntity owner, int durationSec) {
        if (!(victim instanceof ServerPlayerEntity)) {
            enterMob(victim, (ServerWorld) victim.world);
            return;
        }
        ServerPlayerEntity vp = (ServerPlayerEntity) victim;
        ServerWorld overworld = (ServerWorld) vp.world;
        ServerWorld clone = LiminalDimension.get(vp.getServer());
        if (clone == null) {
            vp.sendStatusMessage(new StringTextComponent("\u00A7c\u041B\u0438\u043C\u0438\u043D\u0430\u043B\u044C\u043D\u043E\u0435 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0435 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043E (\u043D\u0443\u0436\u0435\u043D \u043D\u043E\u0432\u044B\u0439 \u043C\u0438\u0440)"), true);
            return;
        }

        State st = new State();
        st.victim = vp.getUniqueID();
        st.center = vp.getPosition();
        st.realReturnPos = vp.getPosition();
        st.durationTicks = durationSec * 20;
        st.frozen = true;
        STATES.put(st.victim, st);

        applyLiminalHit(vp);

        LimboHandler.enterLimbo(vp);
        CopyJob job = new CopyJob(st.victim, overworld, clone, st.center, RADIUS);
        ChunkCopyManager.enqueue(job);
    }

    public static void onCloneReady(CopyJob job) {
        ServerPlayerEntity vp = job.target.getServer().getPlayerList().getPlayerByUUID(job.victim);
        if (vp == null) return;
        State st = STATES.get(job.victim);
        if (st == null) return;

        ChunkPos targetCp = new ChunkPos(st.center);
        job.target.getChunkProvider().registerTicket(TicketType.POST_TELEPORT, targetCp, 1, vp.getEntityId());
        job.target.getChunkProvider().forceChunk(targetCp, true);

        vp.teleport(job.target, st.center.getX() + 0.5, st.center.getY(), st.center.getZ() + 0.5, vp.rotationYaw, vp.rotationPitch);
        LimboHandler.exitLimbo(vp);
        st.cloneReady = true;
        st.frozen = false;
        vp.setGameType(net.minecraft.world.GameType.ADVENTURE);
        vp.removePotionEffect(Effects.JUMP_BOOST);
        vp.removePotionEffect(Effects.BLINDNESS);
        vp.removePotionEffect(Effects.SLOWNESS);

        DeltaCopier.buildFloor(job.target, st.center, RADIUS);
        buildVoidWall(job.target, st.center, RADIUS);
    }

    public static void buildVoidWall(ServerWorld clone, BlockPos center, int radius) {
        int minY = 0, maxY = 200;
        double outer = radius;
        double inner = radius - 1;

        for (int a = 0; a < 3600; a++) {
            double rad = Math.toRadians(a / 10.0);
            int ox = center.getX() + (int) Math.round(Math.cos(rad) * outer);
            int oz = center.getZ() + (int) Math.round(Math.sin(rad) * outer);
            int ix = center.getX() + (int) Math.round(Math.cos(rad) * inner);
            int iz = center.getZ() + (int) Math.round(Math.sin(rad) * inner);

            for (int y = minY; y <= maxY; y++) {
                clone.setBlockState(new BlockPos(ox, y, oz), Blocks.BLACK_CONCRETE.getDefaultState(), 2);
                clone.setBlockState(new BlockPos(ix, y, iz), Blocks.BARRIER.getDefaultState(), 2);
            }
        }
    }

    public static void tick(ServerWorld clone) {
        Iterator<Map.Entry<UUID, State>> it = STATES.entrySet().iterator();
        while (it.hasNext()) {
            State st = it.next().getValue();
            if (!st.cloneReady) continue;
            ServerPlayerEntity vp = clone.getServer().getPlayerList().getPlayerByUUID(st.victim);
            if (vp == null || !vp.isAlive()) {
                cleanupState(vp, st);
                it.remove();
                continue;
            }
            // Lock game mode: no creative/spectator inside the liminal space
            if (vp.isCreative() || vp.isSpectator())
                vp.setGameType(net.minecraft.world.GameType.ADVENTURE);
            st.ticks++;

            // Wall proximity effects
            double dist = Math.sqrt(vp.getDistanceSq(st.center.getX() + 0.5, vp.getPosY(), st.center.getZ() + 0.5));
            if (dist > 90) {
                vp.addPotionEffect(new EffectInstance(Effects.BLINDNESS, 40, 0, false, false));
                vp.addPotionEffect(new EffectInstance(Effects.NAUSEA, 60, 0, false, false));
                clone.spawnParticle(net.minecraft.particles.ParticleTypes.SMOKE,
                    vp.getPosX(), vp.getPosY() + 1, vp.getPosZ(), 20, 0.5, 0.8, 0.5, 0.01);
                clone.spawnParticle(net.minecraft.particles.ParticleTypes.LARGE_SMOKE,
                    vp.getPosX(), vp.getPosY() + 1, vp.getPosZ(), 8, 0.6, 0.9, 0.6, 0.02);
                if (st.ticks % 40 == 0)
                    clone.playSound(null, vp.getPosition(), net.minecraft.util.SoundEvents.AMBIENT_CAVE,
                        net.minecraft.util.SoundCategory.AMBIENT, 0.8F, 0.3F);
            }

            if (st.ticks % 60 == 0 && vp.getHealth() > 1f)
                vp.attackEntityFrom(net.minecraft.util.DamageSource.WITHER, 1f);
            if (st.ticks == 1)
                vp.addPotionEffect(new EffectInstance(Effects.SLOWNESS, st.durationTicks, 1, false, false));
            if (st.ticks % (20 * 20) == 0 && st.zombiesAlive < 6 && vp.getHealth() > 3.0f)
                spawnStunZombie(clone, st, vp.getPosition());

            // Remove zombies when player is critically low (1-3 HP), keep only shadow
            if (vp.getHealth() <= 3.0f && st.zombiesAlive > 0)
                killAllZombies(clone, st);
            // Spawn ghost (shadow) earlier — at 20 seconds
            if (st.ticks >= 20 * 20 && !st.shadowSpawned) {
                st.shadowSpawned = spawnShadow(clone, st, vp);
            }
            // Destruction ticks more often — every 10 seconds after 15s
            if (st.ticks >= 15 * 20 && st.ticks % (10 * 20) == 0)
                rotTick(clone, vp.getPosition(), st);
            if (st.ticks >= st.durationTicks || st.zombiesKilled >= 4) {
                boolean early = st.zombiesKilled >= 4 && st.ticks < st.durationTicks;
                exit(vp, st, early);
                it.remove();
            }
        }
    }

    private static void rotTick(ServerWorld clone, BlockPos center, State state) {
        Random r = clone.rand;
        int decayStage = state.ticks / (15 * 20);

        int range = 8 + decayStage * 4;
        for (BlockPos p : BlockPos.getAllInBoxMutable(center.add(-range, -4 - decayStage, -range), center.add(range, 4 + decayStage, range))) {
            net.minecraft.block.BlockState bs = clone.getBlockState(p);
            if (bs.isAir()) continue;

            Block next = ROT_CHAIN.get(bs.getBlock());
            if (next != null && r.nextFloat() < 0.2f) {
                clone.setBlockState(p, next.getDefaultState(), 18);
                continue;
            }
            if (bs.isIn(BlockTags.LEAVES) && r.nextFloat() < 0.2f) {
                clone.setBlockState(p, Blocks.AIR.getDefaultState(), 18);
                continue;
            }
            if (bs.getBlock() == Blocks.WATER && r.nextFloat() < 0.3f) {
                clone.setBlockState(p, Blocks.BLACK_STAINED_GLASS.getDefaultState(), 18);
                continue;
            }

            // Stage 2+: REAL destruction — blocks vanish
            if (decayStage >= 2 && r.nextFloat() < 0.12f + decayStage * 0.04f) {
                if (bs.getBlock() == Blocks.BLACK_CONCRETE || bs.getBlock() == Blocks.BARRIER
                    || bs.getBlock() == Blocks.BEDROCK) continue;
                clone.setBlockState(p, Blocks.AIR.getDefaultState(), 18);
                clone.spawnParticle(net.minecraft.particles.ParticleTypes.SMOKE,
                    p.getX()+0.5, p.getY()+0.5, p.getZ()+0.5, 5, 0.2,0.2,0.2, 0.02);
            }
        }
    }

    private static void killAllZombies(ServerWorld w, State st) {
        List<StunZombieEntity> zombies = w.getEntitiesWithinAABB(StunZombieEntity.class,
            new net.minecraft.util.math.AxisAlignedBB(st.center).grow(RADIUS));
        for (StunZombieEntity z : zombies) {
            z.remove();
            st.zombiesAlive--;
        }
        if (st.zombiesAlive < 0) st.zombiesAlive = 0;
    }

    private static void cleanupState(ServerPlayerEntity vp, State st) {
        if (vp != null && vp.isAlive()) {
            ServerWorld overworld = vp.getServer().getWorld(net.minecraft.world.World.OVERWORLD);
            if (overworld != null && vp.world.getDimensionKey() != net.minecraft.world.World.OVERWORLD)
                vp.teleport(overworld, st.realReturnPos.getX()+0.5, st.realReturnPos.getY(), st.realReturnPos.getZ()+0.5, vp.rotationYaw, vp.rotationPitch);
            vp.setGameType(net.minecraft.world.GameType.SURVIVAL);
            vp.removePotionEffect(Effects.BLINDNESS);
            vp.removePotionEffect(Effects.SLOWNESS);
            vp.removePotionEffect(Effects.JUMP_BOOST);
        }
    }

    private static void exit(ServerPlayerEntity vp, State st, boolean early) {
        ServerWorld overworld = vp.getServer().getWorld(net.minecraft.world.World.OVERWORLD);
        vp.teleport(overworld, st.realReturnPos.getX()+0.5, st.realReturnPos.getY(), st.realReturnPos.getZ()+0.5, vp.rotationYaw, vp.rotationPitch);
        vp.setGameType(net.minecraft.world.GameType.SURVIVAL);
        vp.removePotionEffect(Effects.BLINDNESS);
        vp.removePotionEffect(Effects.SLOWNESS);
        vp.removePotionEffect(Effects.JUMP_BOOST);
        st.frozen = false;
        if (early) vp.addPotionEffect(new EffectInstance(Effects.WITHER, 10 * 20, 0));
    }

    private static void spawnStunZombie(ServerWorld w, State st, BlockPos near) {
        if (st.zombiesAlive >= 6) return;
        StunZombieEntity z = com.example.titanforge.ModEntities.STUN_ZOMBIE.get().create(w);
        if (z == null) return;
        BlockPos p = near.add(-8 + w.rand.nextInt(16), 0, -8 + w.rand.nextInt(16));
        z.setPosition(p.getX() + 0.5, p.getY(), p.getZ() + 0.5);
        z.setVictim(st.victim);
        w.addEntity(z);
        st.zombiesAlive++;
    }

    private static boolean spawnShadow(ServerWorld w, State st, ServerPlayerEntity owner) {
        ShadowEntity shadow = com.example.titanforge.ModEntities.SHADOW.get().create(w);
        if (shadow == null) {
            TitanForge.LOGGER.warn("[liminal] SHADOW.create() returned null");
            return false;
        }
        double angle = w.rand.nextDouble() * Math.PI * 2;
        double sx = owner.getPosX() + Math.cos(angle) * 20;
        double sz = owner.getPosZ() + Math.sin(angle) * 20;
        shadow.setLocationAndAngles(sx, owner.getPosY() + 1, sz, 0f, 0f);
        shadow.setOwner(owner.getUniqueID());
        boolean ok = w.addEntity(shadow);
        TitanForge.LOGGER.info("[liminal] shadow spawn ok={} at {},{},{}", ok, sx, owner.getPosY(), sz);
        return ok;
    }

    public static void enterMob(LivingEntity victim, ServerWorld world) {
        world.spawnParticle(net.minecraft.particles.ParticleTypes.PORTAL,
            victim.getPosX(), victim.getPosY() + victim.getHeight() / 2, victim.getPosZ(),
            60, 0.4, 0.8, 0.4, 0.3);
        world.spawnParticle(net.minecraft.particles.ParticleTypes.SMOKE,
            victim.getPosX(), victim.getPosY() + 0.2, victim.getPosZ(),
            25, 0.3, 0.1, 0.3, 0.02);
        world.playSound(null, victim.getPosition(),
            net.minecraft.util.SoundEvents.BLOCK_PORTAL_TRIGGER,
            net.minecraft.util.SoundCategory.HOSTILE, 0.7F, 0.4F);
        victim.remove();
    }

    public static boolean isInside(net.minecraft.entity.player.PlayerEntity p) {
        State st = STATES.get(p.getUniqueID());
        return st != null && st.cloneReady;
    }

    // Called when a player dies (LivingDeathEvent). Clears the liminal lock so
    // the respawned player is never left with the jump/slow/blind lock.
    public static void onPlayerDeath(UUID id) {
        State st = STATES.remove(id);
        if (st == null) return;
        st.frozen = false;
        st.markDeadOnRejoin = false;
    }

    public static void clearLockEffects(ServerPlayerEntity vp) {
        vp.removePotionEffect(Effects.BLINDNESS);
        vp.removePotionEffect(Effects.SLOWNESS);
        vp.removePotionEffect(Effects.JUMP_BOOST);
        if (vp.isSpectator() || vp.isCreative())
            vp.setGameType(net.minecraft.world.GameType.SURVIVAL);
    }

    public static void onLogout(UUID id) {
        State st = STATES.get(id);
        if (st != null && st.cloneReady) st.markDeadOnRejoin = true;
    }

    public static void onLogin(ServerPlayerEntity p) {
        State st = STATES.get(p.getUniqueID());
        if (st != null && st.markDeadOnRejoin)
            p.attackEntityFrom(net.minecraft.util.DamageSource.OUT_OF_WORLD, Float.MAX_VALUE);
    }
}
