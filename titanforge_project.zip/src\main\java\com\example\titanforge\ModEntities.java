package com.example.titanforge;

import com.example.titanforge.entities.BlindGolemEntity;
import com.example.titanforge.entities.LiminalArrowEntity;
import com.example.titanforge.entities.LiminalDraughtEntity;
import com.example.titanforge.entities.ShadowEntity;
import com.example.titanforge.entities.StunZombieEntity;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, TitanForge.MOD_ID);

    public static final RegistryObject<EntityType<BlindGolemEntity>> BLIND_GOLEM =
            ENTITIES.register("blind_golem", () -> EntityType.Builder
                    .create(BlindGolemEntity::new, EntityClassification.MISC)
                    .size(1.4F, 2.7F)
                    .build("blind_golem"));

    public static final RegistryObject<EntityType<ShadowEntity>> SHADOW =
            ENTITIES.register("shadow", () -> EntityType.Builder
                    .create(ShadowEntity::new, EntityClassification.MISC)
                    .size(0.6F, 1.8F)
                    .build("shadow"));

    public static final RegistryObject<EntityType<LiminalDraughtEntity>> LIMINAL_DRAUGHT =
            ENTITIES.register("liminal_draught", () -> EntityType.Builder
                    .<LiminalDraughtEntity>create((type, world) -> new LiminalDraughtEntity(type, world), EntityClassification.MISC)
                    .size(0.25F, 0.25F)
                    .build("liminal_draught"));

    public static final RegistryObject<EntityType<LiminalArrowEntity>> LIMINAL_ARROW =
            ENTITIES.register("liminal_arrow", () -> EntityType.Builder
                    .<LiminalArrowEntity>create((type, world) -> new LiminalArrowEntity(type, world), EntityClassification.MISC)
                    .size(0.5F, 0.5F)
                    .build("liminal_arrow"));

    public static final RegistryObject<EntityType<StunZombieEntity>> STUN_ZOMBIE =
            ENTITIES.register("stun_zombie", () -> EntityType.Builder
                    .create(StunZombieEntity::new, EntityClassification.MONSTER)
                    .size(0.6F, 1.95F)
                    .build("stun_zombie"));

    public static void onEntityAttributeCreation(EntityAttributeCreationEvent event) {
        event.put(BLIND_GOLEM.get(), BlindGolemEntity.registerAttributes().create());
        event.put(SHADOW.get(), ShadowEntity.registerAttributes().create());
        event.put(STUN_ZOMBIE.get(), ZombieEntity.func_234342_eQ_()
                .createMutableAttribute(Attributes.MAX_HEALTH, 20.0D)
                .createMutableAttribute(Attributes.MOVEMENT_SPEED, 0.23D)
                .createMutableAttribute(Attributes.ATTACK_DAMAGE, 2.0D)
                .create());
    }
}
