package com.example.titanforge.entities;

import com.example.titanforge.LiminalManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.projectile.ProjectileItemEntity;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.server.ServerWorld;

public class LiminalDraughtEntity extends ProjectileItemEntity {
    private static final double SPLASH_RADIUS = 3.0;

    public LiminalDraughtEntity(net.minecraft.entity.EntityType<?> type, net.minecraft.world.World world) {
        super((net.minecraft.entity.EntityType<? extends ProjectileItemEntity>) type, (LivingEntity) null, world);
    }

    public LiminalDraughtEntity(net.minecraft.world.World world, LivingEntity thrower) {
        super(com.example.titanforge.ModEntities.LIMINAL_DRAUGHT.get(), thrower, world);
    }

    @Override
    protected net.minecraft.item.Item getDefaultItem() {
        return com.example.titanforge.ModItems.LIMINAL_DRAUGHT.get();
    }

    @Override
    protected void onImpact(RayTraceResult result) {
        super.onImpact(result);
        if (world.isRemote) return;
        ServerWorld sw = (ServerWorld) world;

        Entity thrower = getShooter();
        ServerPlayerEntity owner = (thrower instanceof ServerPlayerEntity)
            ? (ServerPlayerEntity) thrower : null;

        for (LivingEntity e : world.getEntitiesWithinAABB(LivingEntity.class,
                getBoundingBox().grow(SPLASH_RADIUS))) {
            if (e == thrower) continue;
            int dur = 120 + rand.nextInt(120);
            LiminalManager.enter(e, owner, dur);
        }
        sw.spawnParticle(net.minecraft.particles.ParticleTypes.PORTAL,
            getPosX(), getPosY(), getPosZ(), 80, 0.6, 0.6, 0.6, 0.4);
        this.remove();
    }
}
