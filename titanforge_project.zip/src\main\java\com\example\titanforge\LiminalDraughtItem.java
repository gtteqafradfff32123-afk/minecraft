package com.example.titanforge;

import com.example.titanforge.entities.LiminalDraughtEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.Stats;
import net.minecraft.util.*;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class LiminalDraughtItem extends Item {
    public LiminalDraughtItem(Properties props) { super(props); }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getHeldItem(hand);
        world.playSound(null, player.getPosX(), player.getPosY(), player.getPosZ(),
            SoundEvents.ENTITY_SPLASH_POTION_THROW, SoundCategory.PLAYERS,
            0.5F, 0.4F / (random.nextFloat() * 0.4F + 0.8F));

        if (!world.isRemote) {
            LiminalDraughtEntity bottle = new LiminalDraughtEntity(world, player);
            bottle.setItem(stack);
            float f = -MathHelper.sin(player.rotationYaw * ((float)Math.PI / 180F)) * MathHelper.cos(player.rotationPitch * ((float)Math.PI / 180F));
            float f1 = -MathHelper.sin((player.rotationPitch - 20.0F) * ((float)Math.PI / 180F));
            float f2 = MathHelper.cos(player.rotationYaw * ((float)Math.PI / 180F)) * MathHelper.cos(player.rotationPitch * ((float)Math.PI / 180F));
            bottle.shoot(f, f1, f2, 0.7F, 1.0F);
            world.addEntity(bottle);
        }
        player.addStat(Stats.ITEM_USED.get(this));
        if (!player.abilities.isCreativeMode) stack.shrink(1);
        return ActionResult.resultSuccess(stack);
    }
}
